module.exports = {
    JWT_SECRET: 'your-secret-key-here',  // 请使用一个安全的随机字符串
    // 其他配置项...
}; 